package database.model;

/**
 * Administrator account, capable of creating businesses
 * @author RK
 */
public class Admin extends Account 
{
	public Admin(String username)
	{	
		super(username);
	}
}
